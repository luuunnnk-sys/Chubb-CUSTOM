import React from 'react';
import { Equipment } from '../types/types';
import { getEquipmentDefinitions } from '../utils/equipmentDefinitions';

interface LegendProps {
  equipment: Equipment[];
}

const Legend: React.FC<LegendProps> = ({ equipment }) => {
  const equipmentDefinitions = getEquipmentDefinitions();
  
  // Compter chaque type d'équipement utilisé (sauf tubage)
  const equipmentCounts = equipment.reduce((counts, eq) => {
    if (eq.type !== 'tubing') {
      counts[eq.type] = (counts[eq.type] || 0) + 1;
    }
    return counts;
  }, {} as Record<string, number>);

  // Filtrer les définitions utilisées (tubage inclus même sans quantitatif)
  const usedEquipment = equipmentDefinitions.filter(def => {
    if (def.type === 'tubing') {
      return equipment.some(eq => eq.type === 'tubing');
    }
    return equipmentCounts[def.type] > 0;
  });

  return (
    <div className="p-4 h-full overflow-y-auto">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Légende du Plan
      </h3>

      {usedEquipment.length === 0 ? (
        <div className="text-center text-gray-500 py-8">
          <div className="text-4xl mb-4">📋</div>
          <p className="text-sm">Aucun équipement placé</p>
          <p className="text-xs text-gray-400 mt-1">
            La légende s'affichera ici automatiquement
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Symboles */}
          <div>
            <h4 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
              Symboles
            </h4>
            <div className="space-y-3">
              {usedEquipment.map((def) => {
                if (def.type === 'tubing') {
                  // ✅ Cas spécial : tubage → trait rouge
                  return (
                    <div key={def.type} className="flex items-center space-x-3">
                      <svg width="32" height="8">
                        <line x1="0" y1="4" x2="32" y2="4" stroke="red" strokeWidth="3" />
                      </svg>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900">
                          {def.name}
                        </div>
                        <div className="text-xs text-gray-500">
                          {def.symbol}
                        </div>
                      </div>
                    </div>
                  );
                }

                const Icon = def.icon;
                const count = equipmentCounts[def.type] || 0;

                return (
                  <div key={def.type} className="flex items-center space-x-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center border-2 flex-shrink-0"
                      style={{ 
                        borderColor: def.color,
                        backgroundColor: def.color + '10' 
                      }}
                    >
                      <Icon 
                        className="w-5 h-5" 
                        style={{ color: def.color }}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-gray-900">
                        {def.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {def.symbol} - Quantité: {count}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Statistiques */}
<div className="border-t border-gray-200 pt-4">
  <h4 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
    Statistiques
  </h4>
  <div className="space-y-2">
    <div className="flex justify-between items-center text-sm">
      <span className="text-gray-600">Total équipements:</span>
      <span className="font-semibold text-gray-900">
        {equipment.filter(eq => eq.type !== 'tubing').length}
      </span>
    </div>
    <div className="flex justify-between items-center text-sm">
      <span className="text-gray-600">Types différents:</span>
      <span className="font-semibold text-gray-900">
        {usedEquipment.filter(def => def.type !== 'tubing').length}
      </span>
    </div>
    {equipment.some(eq => eq.type === 'tubing') && (
      <div className="flex justify-between items-center text-sm">
        <span className="text-gray-600">Ensemble tubulure:</span>
        <span className="font-semibold text-gray-900">1</span>
      </div>
    )}
  </div>
</div>



          {/* Normes */}
          <div className="border-t border-gray-200 pt-4">
            <h4 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
              Conformité
            </h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-xs text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Conforme NF S 61-970</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Conforme Code du Travail</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Legend;
