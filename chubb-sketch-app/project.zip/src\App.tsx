import React, { useState, useRef, useCallback } from 'react';
import { Upload, RotateCcw, Eye, Flame, FileText } from 'lucide-react';
import Canvas from './components/Canvas';
import EquipmentPalette from './components/EquipmentPalette';
import Legend from './components/Legend';
import ProjectInfo from './components/ProjectInfo';
import ExportControls from './components/ExportControls';
import { EquipmentType, Equipment, Project } from './types/types';
import { pdfToImages } from './utils/pdfUtils';

function App() {
  const [project, setProject] = useState<Project>({
    id: Date.now().toString(),
    name: 'Nouveau Projet',
    building: '',
    floor: '',
    date: new Date().toISOString().split('T')[0],
    backgroundImage: null,
    equipment: [],
    scale: 1,
    context: "" // ✅ Contexte du projet
  });

  const [selectedTool, setSelectedTool] = useState<EquipmentType | null>(null);
  const [showLegend, setShowLegend] = useState(true);
  const [showContext, setShowContext] = useState(false); // ✅ toggle affichage contexte
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<any>(null);
  const legendRef = useRef<HTMLDivElement>(null);


  // Gestion PDF multi-pages
  const [pdfPages, setPdfPages] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProject(prev => ({
          ...prev,
          backgroundImage: e.target?.result as string
        }));
        setPdfPages([]);
      };
      reader.readAsDataURL(file);
    } else if (file.type === "application/pdf") {
      const pages = await pdfToImages(file);
      setPdfPages(pages);
      setCurrentPage(0);
      setProject(prev => ({
        ...prev,
        backgroundImage: pages[0]
      }));
    }
  }, []);

  const handleAddEquipment = useCallback((equipment: Equipment) => {
    setProject(prev => ({
      ...prev,
      equipment: [...prev.equipment, equipment]
    }));
  }, []);

  const handleRemoveEquipment = useCallback((id: string) => {
    setProject(prev => ({
      ...prev,
      equipment: prev.equipment.filter(eq => eq.id !== id)
    }));
  }, []);

  const handleClearAll = useCallback(() => {
    setProject(prev => ({
      ...prev,
      equipment: []
    }));
  }, []);

  const handleProjectInfoChange = useCallback((field: keyof Project, value: string) => {
    setProject(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Flame className="w-8 h-8 text-red-600" />
              <h1 className="text-2xl font-bold text-gray-900">Chubb Utility</h1>
            </div>
            <div className="text-sm text-gray-500">v1.0</div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span>Importer Plan</span>
            </button>
            
            <button
              onClick={handleClearAll}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Effacer</span>
            </button>

            <button
              onClick={() => setShowLegend(!showLegend)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                showLegend 
                  ? 'bg-green-600 text-white hover:bg-green-700' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              <Eye className="w-4 h-4" />
              <span>Légende</span>
            </button>

            {/* ✅ Nouveau bouton Contexte */}
            <button
              onClick={() => setShowContext(!showContext)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                showContext 
                  ? 'bg-purple-600 text-white hover:bg-purple-700' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Contexte Projet</span>
            </button>
          </div>
        </div>
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.pdf,.dwg,.dxf"
          onChange={handleFileUpload}
          className="hidden"
        />

        {pdfPages.length > 1 && (
          <div className="flex space-x-2 mt-3">
            <button
              onClick={() => {
                if (currentPage > 0) {
                  const newPage = currentPage - 1;
                  setCurrentPage(newPage);
                  setProject(prev => ({ ...prev, backgroundImage: pdfPages[newPage] }));
                }
              }}
              className="px-3 py-1 bg-gray-200 rounded"
            >
              ← Page précédente
            </button>
            <span className="text-sm text-gray-600 self-center">
              Page {currentPage + 1} / {pdfPages.length}
            </span>
            <button
              onClick={() => {
                if (currentPage < pdfPages.length - 1) {
                  const newPage = currentPage + 1;
                  setCurrentPage(newPage);
                  setProject(prev => ({ ...prev, backgroundImage: pdfPages[newPage] }));
                }
              }}
              className="px-3 py-1 bg-gray-200 rounded"
            >
              Page suivante →
            </button>
          </div>
        )}
      </header>

      <div className="flex flex-1">
        {/* Sidebar gauche */}
        <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
          <ProjectInfo 
            project={project}
            onProjectInfoChange={handleProjectInfoChange}
          />
          
          <EquipmentPalette
            selectedTool={selectedTool}
            onToolSelect={setSelectedTool}
          />

          <ExportControls
            project={project}
            canvasRef={canvasRef}
            legendRef={legendRef}
            setProject={setProject}
          />

          {/* ✅ Bloc contexte affiché si activé */}
          {showContext && (
            <div className="p-3 border-t border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Contexte du projet</h3>
              <textarea
                value={project.context || ""}
                onChange={(e) => setProject(prev => ({ ...prev, context: e.target.value }))}
                placeholder="Décrivez ici le déroulé du projet..."
                className="w-full h-40 border border-gray-300 rounded-lg p-2 text-sm"
              />
            </div>
          )}
        </div>

        {/* Zone Canvas */}
        <div className="flex-1 relative">
          <Canvas
            ref={canvasRef}
            project={project}
            selectedTool={selectedTool}
            onAddEquipment={handleAddEquipment}
            onRemoveEquipment={handleRemoveEquipment}
            onToolComplete={() => setSelectedTool(null)}
          />
        </div>

        {/* Sidebar droite */}
        {showLegend && (
  <div ref={legendRef} className="w-64 bg-white border-l border-gray-200 p-4">
    <Legend equipment={project.equipment} />
  </div>
)}

      </div>
    </div>
  );
}

export default App;
