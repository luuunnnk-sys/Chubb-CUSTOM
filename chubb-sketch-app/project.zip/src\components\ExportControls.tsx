import React from 'react';
import { Download, FileText, Share2, Trash2 } from 'lucide-react';
import { Project } from '../types/types';
import { exportToPDF } from '../utils/exportUtils';

interface ExportControlsProps {
  project: Project;
  canvasRef: React.RefObject<any>;
  legendRef: React.RefObject<HTMLDivElement>;   // 👈 ajouté
  setProject: (p: Project) => void;
}

const ExportControls: React.FC<ExportControlsProps> = ({
  project,
  canvasRef,
  legendRef,
  setProject
}) => {
  const handleExportPDF = async () => {
    try {
      await exportToPDF(
        project,
        canvasRef.current?.getCanvasElement(),
        legendRef.current || undefined   // 👈 on envoie aussi la légende
      );
    } catch (error) {
      console.error("Erreur lors de l'export PDF:", error);
      alert("Erreur lors de l'export PDF. Veuillez réessayer.");
    }
  };

  const handleSaveProject = () => {
    const dataStr = JSON.stringify(project, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${project.name.replace(/[^a-z0-9]/gi, '_')}_${project.id}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleClearAll = () => {
    if (window.confirm("Voulez-vous vraiment supprimer tous les équipements du plan ?")) {
      setProject({ ...project, equipment: [] });
    }
  };

  return (
    <div className="p-4 border-t border-gray-200 mt-auto">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Export & Sauvegarde
      </h3>
      
      <div className="space-y-3">
        <button
          onClick={handleExportPDF}
          disabled={!project.backgroundImage || project.equipment.length === 0}
          className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          <FileText className="w-4 h-4" />
          <span>Exporter PDF</span>
        </button>
        
        <button
          onClick={handleSaveProject}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Sauvegarder Projet</span>
        </button>

        <button
          onClick={handleClearAll}
          disabled={project.equipment.length === 0}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span>Effacer tout</span>
        </button>

        <button
          disabled
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-gray-300 text-gray-500 rounded-lg cursor-not-allowed"
        >
          <Share2 className="w-4 h-4" />
          <span>Partager (Bientôt)</span>
        </button>
      </div>

      <div className="mt-4 text-xs text-gray-500">
        <div className="flex items-center space-x-1 mb-1">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>PDF: Plan + Légende + Infos</span>
        </div>
        <div className="flex items-center space-x-1 mb-1">
          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
          <span>JSON: Sauvegarde complète</span>
        </div>
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
          <span>DWG/DXF: Version Pro</span>
        </div>
      </div>
    </div>
  );
};

export default ExportControls;
