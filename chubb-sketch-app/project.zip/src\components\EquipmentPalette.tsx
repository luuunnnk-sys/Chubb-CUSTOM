import React from 'react';
import { EquipmentType } from '../types/types';
import { getEquipmentDefinitions } from '../utils/equipmentDefinitions';

interface EquipmentPaletteProps {
  selectedTool: EquipmentType | null;
  onToolSelect: (tool: EquipmentType | null) => void;
}

const EquipmentPalette: React.FC<EquipmentPaletteProps> = ({
  selectedTool,
  onToolSelect
}) => {
  const equipmentDefinitions = getEquipmentDefinitions();

  return (
    <div className="p-4 border-b border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Équipements de Sécurité
      </h3>
      
      <div className="grid grid-cols-2 gap-3">
        {equipmentDefinitions.map((equipment) => {
          const Icon = equipment.icon;
          const isSelected = selectedTool === equipment.type;
          
          return (
            <button
              key={equipment.type}
              onClick={() => onToolSelect(isSelected ? null : equipment.type)}
              className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                isSelected
                  ? 'border-blue-500 bg-blue-50 shadow-md'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
              title={equipment.description}
            >
              <div className="flex flex-col items-center space-y-2">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: isSelected ? equipment.color + '20' : '#f3f4f6',
                    color: equipment.color 
                  }}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <span className="text-xs font-medium text-gray-700 text-center leading-tight">
                  {equipment.name}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {selectedTool && (
        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="text-sm font-medium text-blue-900">Outil sélectionné</span>
          </div>
          <p className="text-xs text-blue-700">
            {equipmentDefinitions.find(eq => eq.type === selectedTool)?.description}
          </p>
          <button
            onClick={() => onToolSelect(null)}
            className="mt-2 text-xs text-blue-600 hover:text-blue-800 underline"
          >
            Désélectionner
          </button>
        </div>
      )}
    </div>
  );
};

export default EquipmentPalette;