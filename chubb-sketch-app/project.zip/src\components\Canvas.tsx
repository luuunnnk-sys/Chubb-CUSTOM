import React, { forwardRef, useImperativeHandle, useRef, useState, useCallback } from 'react';
import { Equipment, EquipmentType, Project } from '../types/types';
import { getEquipmentDefinitions } from '../utils/equipmentDefinitions';

interface CanvasProps {
  project: Project;
  selectedTool: EquipmentType | null;
  onAddEquipment: (equipment: Equipment) => void;
  onRemoveEquipment: (id: string) => void;
  onToolComplete: () => void;
}

const Canvas = forwardRef<any, CanvasProps>(({
  project,
  selectedTool,
  onAddEquipment,
  onRemoveEquipment,
  onToolComplete
}, ref) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[] | null>(null);

  useImperativeHandle(ref, () => ({
    getCanvasElement: () => canvasRef.current,
    exportCanvas: () => {
      return canvasRef.current;
    }
  }));

  const handleCanvasClick = useCallback((event: React.MouseEvent) => {
    if (!selectedTool) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    if (selectedTool === 'tubing') {
      if (!currentPath) {
        setCurrentPath([{ x, y }]);
      } else {
        const last = currentPath[currentPath.length - 1];
        const dx = Math.abs(x - last.x);
        const dy = Math.abs(y - last.y);
        const newPoint = dx > dy ? { x, y: last.y } : { x: last.x, y };
        const newPath = [...currentPath, newPoint];
        setCurrentPath(newPath);

        // Double clic pour terminer le tube
        if (event.detail === 2) {
          onAddEquipment({
            id: Date.now().toString(),
            type: 'tubing',
            points: newPath,
            color: 'red'
          });
          setCurrentPath(null);
          onToolComplete();
        }
      }
    } else {
      // Placement équipement ponctuel
      onAddEquipment({
        id: Date.now().toString(),
        type: selectedTool,
        x,
        y,
        rotation: 0
      } as Equipment);
      onToolComplete();
    }
  }, [selectedTool, onAddEquipment, onToolComplete, currentPath]);

  const handleEquipmentDoubleClick = useCallback((equipmentId: string) => {
    onRemoveEquipment(equipmentId);
  }, [onRemoveEquipment]);

  const equipmentDefinitions = getEquipmentDefinitions();

  return (
    <div
      ref={canvasRef}
      className={`relative w-full h-full bg-gray-100 overflow-hidden ${
        selectedTool ? 'cursor-crosshair' : 'cursor-default'
      }`}
      onClick={handleCanvasClick}
    >
      {project.backgroundImage && (
        <div className="absolute top-0 left-0">
          <img
            src={project.backgroundImage}
            alt="Plan de bâtiment"
            className="pointer-events-none select-none block"
            style={{ maxWidth: "100%", height: "auto" }}
          />

          {/* ✅ Tubes (placés + en cours) */}
          <svg className="absolute inset-0 w-full h-full">
            {project.equipment
              .filter(eq => eq.type === 'tubing')
              .map((tube) => (
                <polyline
                  key={tube.id}
                  points={(tube as any).points.map((p: any) => `${p.x},${p.y}`).join(" ")}
                  stroke="red"
                  strokeWidth={3}
                  fill="none"
                  pointerEvents="stroke" // 👈 rend la ligne cliquable
                  onDoubleClick={() => handleEquipmentDoubleClick(tube.id)} // 👈 suppression au double clic
                  style={{ cursor: "pointer" }}
                />
              ))}
            {currentPath && (
              <polyline
                points={currentPath.map((p) => `${p.x},${p.y}`).join(" ")}
                stroke="red"
                strokeWidth={2}
                fill="none"
                strokeDasharray="4 2"
              />
            )}
          </svg>

          {/* ✅ Équipements ponctuels */}
          <div className="absolute inset-0">
            {project.equipment
              .filter(eq => eq.type !== 'tubing')
              .map((equipment) => {
                const definition = equipmentDefinitions.find(def => def.type === equipment.type);
                if (!definition) return null;

                const Icon = definition.icon;
                return (
                  <div
                    key={equipment.id}
                    className="absolute flex items-center justify-center w-8 h-8 cursor-pointer hover:scale-110 transition-transform"
                    style={{
                      left: (equipment as any).x - 16,
                      top: (equipment as any).y - 16,
                      color: definition.color,
                      transform: `rotate(${(equipment as any).rotation || 0}deg)`
                    }}
                    onDoubleClick={() => handleEquipmentDoubleClick(equipment.id)} // 👈 suppression ponctuelle
                    title={definition.name}
                  >
                    <div 
                      className="flex items-center justify-center w-8 h-8 rounded-full bg-white shadow-lg border-2"
                      style={{ borderColor: definition.color }}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {!project.backgroundImage && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-500">
          <div className="text-center">
            <div className="text-6xl mb-4">📐</div>
            <h3 className="text-xl font-medium mb-2">Importez un plan de bâtiment</h3>
            <p className="text-sm">Cliquez sur "Importer Plan" pour commencer</p>
          </div>
        </div>
      )}
    </div>
  );
});

Canvas.displayName = 'Canvas';
export default Canvas;
