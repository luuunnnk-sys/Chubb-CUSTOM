import { 
  Zap, 
  Flame, 
  Volume2, 
  Radio,
  PenTool
} from 'lucide-react';
import { EquipmentDefinition } from '../types/types';

export function getEquipmentDefinitions(): EquipmentDefinition[] {
  return [
    {
      type: 'smoke-detector',
      name: 'Détecteur de Fumée',
      icon: Flame,
      color: '#DC2626',
      description: 'Détecteur automatique de fumée selon NF S 61-970',
      symbol: 'DF'
    },
    {
      type: 'manual-trigger',
      name: 'Déclencheur Manuel',
      icon: Zap,
      color: '#EA580C',
      description: 'Déclencheur manuel d\'alarme incendie',
      symbol: 'DM'
    },
    {
      type: 'sounder',
      name: 'Diffuseur Sonore',
      icon: Volume2,
      color: '#7C3AED',
      description: 'Avertisseur sonore d\'évacuation',
      symbol: 'DS'
    },
    {
      type: 'flash',
      name: 'Flash',
      icon: Radio,
      color: '#0ea5e9',
      description: 'Diffuseur lumineux type BAAS Flash',
      symbol: 'FL'
    },
    {
      type: 'vesda',
      name: 'VESDA',
      icon: Zap,
      color: '#16a34a',
      description: 'Système de détection par aspiration (VESDA)',
      symbol: 'VE'
    },
    {
      type: 'tubing',
      name: 'Tubage VESDA',
      icon: PenTool,
      color: '#DC2626',
      description: 'Tubage rouge pour réseau VESDA',
      symbol: 'TU'
    }
  ];
}
