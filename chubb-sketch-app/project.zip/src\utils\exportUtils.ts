import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { Project } from "../types/types";
import { getEquipmentDefinitions } from "./equipmentDefinitions";

// ⚡ Mapping type → logo (placer tes PNG/SVG dans /public/icons/)
const ICONS: Record<string, string> = {
  "smoke-detector": "/icons/smoke.png",
  "manual-trigger": "/icons/dm.png",
  "sounder": "/icons/sounder.png",
  "flash": "/icons/flash.png",
  "vesda": "/icons/vesda.png",
  "tubing": "/icons/tube.png"
};

export async function exportToPDF(
  project: Project,
  canvasElement: HTMLElement | null
) {
  if (!canvasElement) {
    throw new Error("Élément canvas non trouvé");
  }

  try {
    const pdf = new jsPDF("landscape", "mm", "a3");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    const margin = 10;
    const contentWidth = pageWidth - margin * 2;
    const contentHeight = pageHeight - margin * 2;

    // === En-tête ===
    pdf.setFontSize(18);
    pdf.setFont("helvetica", "bold");
    pdf.text("Implantation DI", margin, margin + 8);

    pdf.setFontSize(11);
    pdf.setFont("helvetica", "normal");
    pdf.text(`Projet: ${project.name}`, margin, margin + 18);
    pdf.text(`Bâtiment: ${project.building}`, margin, margin + 25);
    pdf.text(`Étage/Zone: ${project.floor}`, margin, margin + 32);
    pdf.text(
      `Date: ${new Date(project.date).toLocaleDateString("fr-FR")}`,
      margin,
      margin + 39
    );

    // === Plan (gauche) ===
    const planCanvas = await html2canvas(canvasElement, {
      scale: 2,
      backgroundColor: "#ffffff",
    });
    const planImg = planCanvas.toDataURL("image/png");

    const planY = margin + 50;
    const planMaxHeight = contentHeight - 50;
    const aspect = planCanvas.width / planCanvas.height;

    let planWidth = contentWidth * 0.5;
    let planHeight = planWidth / aspect;
    if (planHeight > planMaxHeight) {
      planHeight = planMaxHeight;
      planWidth = planHeight * aspect;
    }

    pdf.addImage(planImg, "PNG", margin, planY, planWidth, planHeight);

    // === Légende (colonne centrale) ===
    const legendX = margin + planWidth + 20;
    let legendY = planY + 10;
    const legendWidth = contentWidth * 0.2;

    // Titre légende
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(12);
    pdf.text("Légende du plan", legendX, legendY);
    legendY += 4;
    pdf.setDrawColor(150); // gris
    pdf.line(legendX, legendY, legendX + legendWidth, legendY);
    legendY += 8;

    const equipmentDefinitions = getEquipmentDefinitions();
    const usedEquipment = equipmentDefinitions.filter((def) =>
      project.equipment.some((eq) => eq.type === def.type)
    );

    // ✅ Boucle avec logos
    for (const def of usedEquipment) {
      const count = project.equipment.filter(
        (eq) => eq.type === def.type
      ).length;

      // Logo
      if (ICONS[def.type]) {
        try {
          const img = await fetch(ICONS[def.type]).then((r) => r.blob());
          const imgData = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.readAsDataURL(img);
          });
          pdf.addImage(imgData, "PNG", legendX, legendY - 5, 6, 6);
        } catch (err) {
          console.error("Erreur chargement icône PDF:", err);
        }
      }

      // Texte
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(10);
      pdf.text(`${def.name} (${def.symbol}) : ${count}`, legendX + 12, legendY);

      legendY += 10;
    }

    // === Statistiques ===
    pdf.setDrawColor(150); // gris
    pdf.line(legendX, legendY, legendX + legendWidth, legendY);
    legendY += 6;
    pdf.setFont("helvetica", "bold");
    pdf.text("Statistiques", legendX, legendY);
    legendY += 6;
    pdf.setFont("helvetica", "normal");
    pdf.text(
      `Total équipements : ${project.equipment.length}`,
      legendX,
      legendY
    );
    legendY += 6;
    pdf.text(`Types différents : ${usedEquipment.length}`, legendX, legendY);

    // === Conformité ===
    legendY += 10;
    pdf.setDrawColor(150);
    pdf.line(legendX, legendY, legendX + legendWidth, legendY);
    legendY += 6;
    pdf.setFont("helvetica", "bold");
    pdf.text("Conformité", legendX, legendY);
    legendY += 6;
    pdf.setFont("helvetica", "normal");
    pdf.text("✓ Conforme NF S 61-970", legendX, legendY);
    legendY += 6;
    pdf.text("✓ Conforme Code du Travail", legendX, legendY);

    // === Contexte du projet (colonne droite) ===
    const ctxX = legendX + legendWidth + 20;
    const ctxY = planY + 10;

    // Trait vertical gris entre légende et contexte
    pdf.setDrawColor(180);
    pdf.line(ctxX - 10, planY, ctxX - 10, legendY);

    if (project.context && project.context.trim() !== "") {
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(12);
      pdf.text("Contexte du projet :", ctxX, ctxY);

      // ✅ Trait horizontal aligné avec celui de la légende
      pdf.setDrawColor(150);
      pdf.line(ctxX, ctxY + 4, ctxX + legendWidth, ctxY + 4);

      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(10);
      const wrapped = pdf.splitTextToSize(project.context, legendWidth);
      pdf.text(wrapped, ctxX, ctxY + 12);
    }

    // ✅ Sauvegarde
    const fileName = `Implantation_DI_${project.name.replace(
      /[^a-z0-9]/gi,
      "_"
    )}_${Date.now()}.pdf`;
    pdf.save(fileName);
  } catch (err) {
    console.error("Erreur PDF:", err);
    throw err;
  }
}
