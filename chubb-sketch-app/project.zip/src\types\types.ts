export type EquipmentType =
  | 'smoke-detector'
  | 'manual-trigger'
  | 'sounder'
  | 'flash'
  | 'vesda'
  | 'tubing';

// Type discriminé → TS sait ce qui existe selon le type
export type Equipment =
  | {
      id: string;
      type: 'smoke-detector' | 'manual-trigger' | 'sounder' | 'flash' | 'vesda';
      x: number;
      y: number;
      rotation?: number;
      label?: string;
      zone?: string;
    }
  | {
      id: string;
      type: 'tubing';
      points: { x: number; y: number }[];
      color: string;
    };

export interface Project {
  id: string;
  name: string;
  building: string;
  floor: string;
  date: string;
  backgroundImage: string | null;
  equipment: Equipment[];
  scale: number;
  context?: string;
}

export interface EquipmentDefinition {
  type: EquipmentType;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  description: string;
  symbol: string;
}
